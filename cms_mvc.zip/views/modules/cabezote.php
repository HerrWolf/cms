<header class="row">
	
	<!-- LOGOTIPO -->

	<div id="logo" class="col-lg-3 col-md-3 col-sm-12 col-xs-12">
			
		<img src="views/images/logotipo.png" class="img-responsive">

	</div>

	<!-- BOTONERA MOVIL -->
	
	<div id="botoneraMovil" class="navbar-header navbar-inverse">

		<button type="button" class="navbar-toggle pull-left" data-toggle="collapse" data-target="#botonera">

			<span class="icon-bar"></span>
    		<span class="icon-bar"></span>
   			<span class="icon-bar"></span>

		</button>
	
	</div>

	<!-- BOTONERA NORMAL -->
	
	<nav id="botonera" class="col-lg-9 col-md-9 col-sm-12 col-xs-12 collapse navbar-collapse pull-right">
				
		<ul class="nav navbar-nav">

			<li><a href="#top">Noticias</a></li>
			<li><a href="#galeria">Galería</a></li>
			<li><a href="#articulos">Artículos</a></li>
			<li><a href="#videos">Videos</a></li>
			<li><a href="#contactenos">Contáctenos</a></li>

		</ul>

	</nav>

</header>