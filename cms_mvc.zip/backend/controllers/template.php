<?php 

class TemplateController{


	/*==============================================
	=            LLAMADA A LA PLANTILLA            =
	==============================================*/
	
	
	public function template(){

		include "views/template.php";
	}

	/*=====  End of LLAMADA A LA PLANTILLA  ======*/


}