<?php

require_once "../../models/gestorGaleria.php";
require_once "../../controllers/gestorGaleria.php";

/*========================================
=            CLASES Y METODOS            =
========================================*/


class Ajax{

	/*====================================
	=            SUBIR IMAGEM            =
	====================================*/
	
	
	public $imagenTemporal;
	
	/*=====  End of SUBIR IMAGEM  ======*/
	

}





/*=====  End of CLASES Y METODOS  ======*/




/*===============================
=            OBJETOS            =
===============================*/







/*=====  End of OBJETOS  ======*/
